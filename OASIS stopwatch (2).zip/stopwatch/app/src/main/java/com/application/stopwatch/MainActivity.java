package com.application.stopwatch;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView stopwatchDisplay;
    private Button startButton, stopButton, resetButton;
    private boolean running = false;
    private long startTime = 0L;
    private Handler handler = new Handler();
    private long timeMilliseconds = 0L;
    private long updatedTime = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stopwatchDisplay = findViewById(R.id.stopwatchDisplay);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        resetButton = findViewById(R.id.resetButton);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startStopwatch();
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopStopwatch();
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetStopwatch();
            }
        });
    }

    public void startStopwatch() {
        if (!running) {
            startTime = System.currentTimeMillis() - timeMilliseconds;
            handler.postDelayed(updateTimer, 0);
            running = true;
            startButton.setEnabled(false);
        }
    }

    public void stopStopwatch() {
        if (running) {
            handler.removeCallbacks(updateTimer);
            running = false;
            startButton.setEnabled(true);
        }
    }

    public void resetStopwatch() {
        stopStopwatch();
        timeMilliseconds = 0L;
        updatedTime = 0L;
        stopwatchDisplay.setText("00:00:00");
    }

    private Runnable updateTimer = new Runnable() {
        public void run() {
            timeMilliseconds = System.currentTimeMillis() - startTime;
            updatedTime = timeMilliseconds;
            int secs = (int) (updatedTime / 1000);
            int mins = secs / 60;
            secs %= 60;
            int milliseconds = (int) (updatedTime % 1000);
            stopwatchDisplay.setText(String.format("%02d:%02d:%03d", mins, secs, milliseconds));
            handler.postDelayed(this, 0);
        }
    };
}
