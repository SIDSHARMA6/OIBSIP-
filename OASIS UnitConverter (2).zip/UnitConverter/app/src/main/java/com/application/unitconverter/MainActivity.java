package com.application.unitconverter;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputValue;
    private Spinner spinnerFrom;
    private Spinner spinnerTo;
    private Button convertButton;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputValue = findViewById(R.id.inputValue);
        spinnerFrom = findViewById(R.id.spinnerFrom);
        spinnerTo = findViewById(R.id.spinnerTo);
        convertButton = findViewById(R.id.convertButton);
        resultText = findViewById(R.id.resultText);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.unit_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerFrom.setAdapter(adapter);
        spinnerTo.setAdapter(adapter);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convert();
            }
        });
    }

    private void convert() {
        // Get the selected units from spinners
        String unitFrom = spinnerFrom.getSelectedItem().toString();
        String unitTo = spinnerTo.getSelectedItem().toString();

        // Get the input value as a string
        String inputText = inputValue.getText().toString();

        // Check if the input is empty or not a valid number
        if (inputText.isEmpty()) {
            resultText.setText("Enter a valid numeric value.");
            return; // Exit the method
        }

        try {
            // Parse the input value
            double value = Double.parseDouble(inputText);

            // Implement your conversion logic here
            double result = performConversion(value, unitFrom, unitTo);

            // Display the result
            resultText.setText("Result: " + result + " " + unitTo);
        } catch (NumberFormatException e) {
            resultText.setText("Invalid input. Enter a valid numeric value.");
        }
    }

    private double performConversion(double value, String unitFrom, String unitTo) {
        double result = 0.0;

        switch (unitFrom) {
            case "Inch":
                switch (unitTo) {
                    case "Meter":
                        result = value * 0.0254;
                        break;
                    case "Foot":
                        result = value * 0.0833333;
                        break;
                    case "Kilometer":
                        result = value * 0.0000254;
                        break;
                    case "Centimeter":
                        result = value * 2.54;
                        break;
                    case "Mile":
                        result = value * 0.0000158;
                        break;
                }
                break;

            case "Meter":
                switch (unitTo) {
                    case "Inch":
                        result = value * 39.3701;
                        break;
                    case "Foot":
                        result = value * 3.28084;
                        break;
                    case "Kilometer":
                        result = value * 0.001;
                        break;
                    case "Centimeter":
                        result = value * 100;
                        break;
                    case "Mile":
                        result = value * 0.000621371;
                        break;
                }
                break;

            case "Foot":
                switch (unitTo) {
                    case "Inch":
                        result = value * 12.0;
                        break;
                    case "Meter":
                        result = value * 0.3048;
                        break;
                    case "Kilometer":
                        result = value * 0.0003048;
                        break;
                    case "Centimeter":
                        result = value * 30.48;
                        break;
                    case "Mile":
                        result = value * 0.000189394;
                        break;
                }
                break;

            case "Kilometer":
                switch (unitTo) {
                    case "Inch":
                        result = value * 39370.1;
                        break;
                    case "Meter":
                        result = value * 1000.0;
                        break;
                    case "Foot":
                        result = value * 3280.84;
                        break;
                    case "Centimeter":
                        result = value * 100000;
                        break;
                    case "Mile":
                        result = value * 0.621371;
                        break;
                }
                break;

            case "Centimeter":
                switch (unitTo) {
                    case "Inch":
                        result = value * 0.393701;
                        break;
                    case "Meter":
                        result = value * 0.01;
                        break;
                    case "Foot":
                        result = value * 0.0328084;
                        break;
                    case "Kilometer":
                        result = value * 0.00001;
                        break;
                    case "Mile":
                        result = value * 0.0000062137;
                        break;
                }
                break;

            case "Mile":
                switch (unitTo) {
                    case "Inch":
                        result = value * 63360.0;
                        break;
                    case "Meter":
                        result = value * 1609.34;
                        break;
                    case "Foot":
                        result = value * 5280.0;
                        break;
                    case "Kilometer":
                        result = value * 1.60934;
                        break;
                    case "Centimeter":
                        result = value * 160934.0;
                        break;
                }
                break;
        }

        return result;
    
    }
}
